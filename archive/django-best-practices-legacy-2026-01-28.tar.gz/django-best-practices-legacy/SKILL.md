---
name: django-best-practices
description: Comprehensive Django and Python best practices focusing on foreign keys, database migrations, concurrency handling, transactions, and signals. Use when writing Django code, reviewing models, creating migrations, handling concurrent operations, or implementing signal-based workflows. Essential for production-ready Django applications.
---

# Django Best Practices

This skill provides battle-tested Django patterns and practices based on real-world production experience. It covers the most critical and commonly misunderstood aspects of Django development.

## Core Topics

This skill covers:

1. **Foreign Keys & Migrations** - Index management, migration safety, concurrent operations
2. **Concurrency** - Race condition prevention, locking strategies, F() expressions
3. **Transactions** - Nested transaction pitfalls, on_commit patterns, testing
4. **Signals** - Reliable signal patterns, transaction coupling, decoupling modules
5. **Query Optimization & N+1 Problem** - select_related, prefetch_related, avoiding performance pitfalls
6. **Advanced Database Techniques** - Custom functions, BRIN indexes, GROUPING SETS, statement timeout

## Quick Reference

### Foreign Key Checklist

When creating or modifying foreign keys:

- [ ] Set `db_index` explicitly (True or False)
- [ ] Add comment explaining index decision
- [ ] Check if partial index would save space (nullable FKs)
- [ ] Review generated migration SQL before applying
- [ ] Use concurrent operations for production migrations
- [ ] Specify `of=('self',)` in `select_for_update()`
- [ ] Use `no_key=True` when not updating keys

### Concurrency Checklist

When updating data:

- [ ] Use F() expressions for simple updates
- [ ] Prefer EAFP (try/except) over checking then creating
- [ ] Avoid `select_for_update()` unless necessary
- [ ] Test with concurrent operations
- [ ] Never check-then-create without handling races

### Transaction Checklist

When using transactions:

- [ ] Use `on_commit` for side effects
- [ ] Keep transactions short
- [ ] Document if function requires/forbids transactions
- [ ] Test `on_commit` callbacks with proper fixtures
- [ ] Never send signals inside transactions (use `on_commit`)

### Query Optimization Checklist

When fetching related data:

- [ ] Use `select_related()` for ForeignKey/OneToOne
- [ ] Use `prefetch_related()` for ManyToMany/Reverse FK
- [ ] Check query count in development (django-debug-toolbar)
- [ ] Avoid accessing relations inside loops without prefetch
- [ ] Use `Prefetch()` object for filtered/ordered prefetches
- [ ] Don't defeat the cache (work on objects, not new queries)

### Database Performance Checklist

When working with databases:

- [ ] Set statement_timeout (30s recommended)
- [ ] Use BRIN indexes for time-series/sequential data
- [ ] Consider LIMIT + 1 trick for bounded queries
- [ ] Use `values_list(named=True)` for cleaner code
- [ ] Leverage `filter` parameter in aggregations (Django 2.0+)
- [ ] Create custom Func for database-specific operations
- [ ] Monitor slow queries in production

## Critical Patterns

### 1. Safe Foreign Key Modification

```python
# Always explicit about indexes
category = models.ForeignKey(
    to=Category,
    on_delete=models.PROTECT,
    db_index=False,  # Indexed in unique constraint
)

created_by = models.ForeignKey(
    to=User,
    on_delete=models.PROTECT,
    db_index=True,  # Used to speed up user deletion
)
```

### 2. Concurrent-Safe Updates

```python
# ✅ BEST - F() expression
obj.counter = F('counter') + 1
obj.save(update_fields=['counter'])

# ✅ Good - EAFP for uniqueness
while True:
    try:
        with transaction.atomic():
            return Model.objects.create(key=random_key())
    except IntegrityError:
        continue
```

### 3. Safe Signal Usage

```python
def mark_paid(pk: int):
    with transaction.atomic():
        payout = Payout.objects.get(pk=pk)
        payout.status = 'paid'
        payout.save()
        
        # Only fire after commit
        transaction.on_commit(
            lambda: signals.payout_paid.send_robust(payout=payout)
        )
```

### 4. Query Optimization (Avoid N+1)

```python
# ❌ BAD - N+1 queries (1 + 100 queries)
products = Product.objects.all()[:100]
for product in products:
    print(product.category.name)  # Query per product!

# ✅ GOOD - Single query with JOIN
products = Product.objects.select_related('category').all()[:100]
for product in products:
    print(product.category.name)  # No additional queries!

# ✅ GOOD - For ManyToMany (3 queries total)
orders = Order.objects.prefetch_related('items__program').all()[:100]
for order in orders:
    for item in order.items.all():
        print(item.program.name)  # Cached!
```

## Detailed References

For comprehensive coverage of each topic, read the appropriate reference file:

### Foreign Keys and Migrations

**When to read:** Creating/modifying foreign keys, writing migrations, optimizing indexes

See [references/foreign-keys-migrations.md](references/foreign-keys-migrations.md) for:
- Complete foreign key configuration guide
- Migration best practices and pitfalls
- Concurrent index operations
- Partial indexes for nullable FKs
- Locking strategies and `select_for_update` patterns

### Concurrency

**When to read:** Updating data, handling uniqueness constraints, avoiding race conditions

See [references/concurrency.md](references/concurrency.md) for:
- TOCTOU (Time-of-Check to Time-of-Use) patterns
- F() expressions and when to use them
- Lock-free concurrency patterns
- select_for_update strategies
- Testing concurrent operations

### Transactions and Signals

**When to read:** Using Django signals, managing transactions, bulk operations

See [references/transactions-signals.md](references/transactions-signals.md) for:
- Nested transaction pitfalls
- on_commit patterns and testing
- Signal reliability considerations
- Decoupling modules with signals
- Transaction best practices

### Query Optimization and N+1 Problem

**When to read:** Fetching related data, optimizing database queries, avoiding performance issues

See [references/query-optimization-n-plus-one.md](references/query-optimization-n-plus-one.md) for:
- Complete N+1 problem explanation and examples
- select_related vs prefetch_related guide
- Prefetch object advanced usage
- Django Admin optimization techniques
- Detecting and debugging N+1 problems
- Common patterns and pitfalls

### Advanced Database Techniques

**When to read:** Working with complex queries, performance optimization, database-specific features

See [references/advanced-database-techniques.md](references/advanced-database-techniques.md) for:
- Statement timeout configuration (critical!)
- Custom database functions (Func expressions)
- BRIN vs B-Tree indexes
- LIMIT + 1 trick for bounded queries
- Advanced aggregation with GROUPING SETS
- Named tuples from querysets
- Aggregation with filter parameter
- Raw SQL best practices
- Performance monitoring techniques

## Common Anti-Patterns to Avoid

### ❌ Don't: Use unique_together

```python
# DEPRECATED
class Meta:
    unique_together = (('field1', 'field2'),)
```

**Instead:** Use UniqueConstraint
```python
class Meta:
    constraints = [
        models.UniqueConstraint(
            name='my_unique_constraint',
            fields=('field1', 'field2'),
        ),
    ]
```

### ❌ Don't: Check Then Create

```python
# Race condition!
if not Model.objects.filter(key=key).exists():
    Model.objects.create(key=key)
```

**Instead:** Try to create, handle violation
```python
try:
    with transaction.atomic():
        return Model.objects.create(key=key)
except IntegrityError:
    # Handle conflict
```

### ❌ Don't: Update Based on Fetched Value

```python
# Can lose updates!
obj.counter += 1
obj.save()
```

**Instead:** Use F() expression
```python
obj.counter = F('counter') + 1
obj.save(update_fields=['counter'])
```

### ❌ Don't: Send Signals in Transactions

```python
# Fires even if transaction rolls back!
with transaction.atomic():
    obj.save()
    signals.saved.send(obj=obj)
```

**Instead:** Use on_commit
```python
with transaction.atomic():
    obj.save()
    transaction.on_commit(
        lambda: signals.saved.send(obj=obj)
    )
```

### ❌ Don't: Apply Migrations Without Checking SQL

```python
# Danger!
./manage.py migrate
```

**Instead:** Always review SQL first
```bash
./manage.py sqlmigrate app_name 0001
# Review output, then migrate
./manage.py migrate
```

### ❌ Don't: Access Related Objects in Loops Without Prefetch

```python
# N+1 Problem - 101 queries!
products = Product.objects.all()[:100]
for product in products:
    print(product.category.name)  # Query per product!
```

**Instead:** Use select_related or prefetch_related
```python
# 1 query with JOIN
products = Product.objects.select_related('category')[:100]
for product in products:
    print(product.category.name)  # Cached!

# For ManyToMany - 3 queries total
orders = Order.objects.prefetch_related('items__program')[:100]
for order in orders:
    for item in order.items.all():
        print(item.program.name)  # Cached!
```

## Testing Considerations

### Test on_commit Callbacks

```python
# Django TestCase
from django.test import TestCase

class MyTest(TestCase):
    def test_signal_after_commit(self):
        with self.captureOnCommitCallbacks(execute=True):
            mark_as_paid(pk=1)
        assert notification_sent

# pytest-django (4.4+)
def test_signal_after_commit(django_capture_on_commit_callbacks):
    with django_capture_on_commit_callbacks(execute=True):
        mark_as_paid(pk=1)
    assert notification_sent
```

### Test Concurrent Operations

```python
from threading import Thread

def test_concurrent_updates():
    def increment():
        obj = Model.objects.get(id=1)
        obj.counter = F('counter') + 1
        obj.save()
    
    threads = [Thread(target=increment) for _ in range(10)]
    for t in threads:
        t.start()
    for t in threads:
        t.join()
    
    obj = Model.objects.get(id=1)
    assert obj.counter == 10
```

## Decision Trees

### Should I Use select_for_update()?

```
Do you need current value for business logic?
    ├─ No → Use F() expression
    └─ Yes → Do you have high concurrency?
        ├─ No → select_for_update() is fine
        └─ Yes → Consider optimistic locking or restructure with F()
```

### Should I Create an Index on This Foreign Key?

```
Is FK included in unique constraint or other index?
    ├─ Yes → db_index=False (document it)
    └─ No → Will I query by this FK or does model use CASCADE/PROTECT?
        ├─ No → db_index=False (document it)
        └─ Yes → Is FK nullable and mostly NULL (>90%)?
            ├─ Yes → Use partial index in Meta
            └─ No → db_index=True
```

### What Type of Lock Should I Use?

```
Updating only regular columns (not PKs/unique constraints)?
    ├─ Yes → select_for_update(of=('self',), no_key=True)
    └─ No → Updating PK or unique constraint referenced by FK?
        ├─ Yes → select_for_update(of=('self',))
        └─ No → select_for_update()
```

## Migration Safety Checklist

Before deploying migrations to production:

1. **Review SQL**: Run `./manage.py sqlmigrate app_name migration_number`
2. **Check for blocking operations**:
   - Adding NOT NULL without default
   - Adding unique constraints
   - Recreating foreign keys unnecessarily
3. **Use concurrent operations**:
   - Set `atomic = False`
   - Use `AddIndexConcurrently` / `RemoveIndexConcurrently`
   - Or use `migrations.RunSQL` with `CONCURRENTLY`
4. **Provide reverse operations**: Always specify reverse SQL
5. **Order matters**: Create new before dropping old
6. **Split when needed**: Move concurrent ops to separate migration

## When to Read Each Reference

| Task | Read |
|------|------|
| Creating/modifying ForeignKey | foreign-keys-migrations.md |
| Writing migrations | foreign-keys-migrations.md |
| Optimizing indexes | foreign-keys-migrations.md |
| Updating data concurrently | concurrency.md |
| Handling uniqueness constraints | concurrency.md |
| Incrementing counters | concurrency.md |
| Using Django signals | transactions-signals.md |
| Bulk operations | transactions-signals.md |
| on_commit patterns | transactions-signals.md |
| Testing transactions | transactions-signals.md |
| Optimizing queries | query-optimization-n-plus-one.md |
| Fixing N+1 problems | query-optimization-n-plus-one.md |
| Admin list performance | query-optimization-n-plus-one.md |
| API serialization performance | query-optimization-n-plus-one.md |
| Statement timeout setup | advanced-database-techniques.md |
| Custom database functions | advanced-database-techniques.md |
| BRIN/B-Tree index choice | advanced-database-techniques.md |
| Complex aggregations | advanced-database-techniques.md |
| GROUPING SETS usage | advanced-database-techniques.md |
| Performance monitoring | advanced-database-techniques.md |

## Philosophy

These practices are based on real production experience from hakibenita.com articles. They emphasize:

1. **Explicit over implicit** - Always state your intentions clearly
2. **Safety over convenience** - Prevent bugs before they happen  
3. **Performance aware** - Understand cost of operations
4. **Production ready** - Patterns that work under real load
5. **Test everything** - Especially concurrent operations
