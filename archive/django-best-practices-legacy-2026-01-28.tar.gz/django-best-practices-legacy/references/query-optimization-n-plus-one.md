# Query Optimization and N+1 Problem

Sources:
- https://hakibenita.com/things-you-must-know-about-django-admin-as-your-app-gets-bigger
- https://hakibenita.com/all-you-need-to-know-about-prefetching-in-django
- https://hakibenita.com/django-rest-framework-slow
- https://hakibenita.com/9-django-tips-for-working-with-databases
- https://docs.sentry.io/product/issues/issue-details/performance-issues/n-one-queries/
- https://johnnymetz.com/posts/avoiding-duplicate-objects-in-django-querysets/

## The N+1 Query Problem

### What is the N+1 Problem?

The N+1 query problem occurs when:
1. **One initial query** fetches N objects
2. **N additional queries** execute to fetch related data for each object

**Result:** 1 + N total queries instead of 1 or 2 optimized queries.

### Classic Example

```python
# ❌ BAD - N+1 Problem
class Category(models.Model):
    name = models.CharField(max_length=50)

class Product(models.Model):
    name = models.CharField(max_length=50)
    category = models.ForeignKey(Category, on_delete=models.PROTECT)

# Display products with category names
products = Product.objects.all()[:100]  # 1 query
for product in products:
    print(product.category.name)  # 100 additional queries!
```

**SQL Log:**
```sql
-- Query 1: Fetch products
SELECT * FROM product LIMIT 100;

-- Queries 2-101: Fetch each category individually
SELECT * FROM category WHERE id = 1;
SELECT * FROM category WHERE id = 2;
SELECT * FROM category WHERE id = 1;  -- Duplicate!
SELECT * FROM category WHERE id = 3;
-- ... 96 more queries
```

**Total:** 101 queries for 100 products!

## Solutions for ForeignKey Relations

### Solution 1: select_related() (For ForeignKey/OneToOne)

```python
# ✅ GOOD - Single query with JOIN
products = Product.objects.select_related('category').all()[:100]
for product in products:
    print(product.category.name)  # No additional queries!
```

**SQL Generated:**
```sql
SELECT 
    product.id, product.name, product.category_id,
    category.id, category.name
FROM product
INNER JOIN category ON (product.category_id = category.id)
LIMIT 100;
```

**Total:** 1 query for 100 products! ✅

**When to use:**
- Following ForeignKey relationships
- Following OneToOneField relationships
- When you need the related object for EVERY item
- "One-to-one" or "many-to-one" relationships

**Performance:**
- Uses SQL JOIN
- Single query
- Can include multiple relations: `.select_related('category', 'supplier', 'created_by')`
- Can chain: `.select_related('category__parent')`

### Solution 2: values_list() with Snake Case

```python
# ✅ GOOD - Fetch only what you need
product_names = Product.objects.values_list(
    'name', 
    'category__name'
)[:100]
```

**When to use:**
- You only need specific fields
- Don't need full model instances
- Want to reduce memory usage

## Solutions for ManyToMany Relations

### The Problem with ManyToMany

```python
# Models
class Price(models.Model):
    program = models.ForeignKey(Program, on_delete=models.PROTECT)
    amount = models.DecimalField(max_digits=10, decimal_places=2)

class Order(models.Model):
    items = models.ManyToManyField(Price)

# ❌ BAD - N+1 Problem
orders = Order.objects.all()[:100]  # 1 query
for order in orders:
    for item in order.items.all():  # 100 queries
        print(item.program.name)  # 100 more queries!
```

**Why can't we JOIN?**

If we JOIN many-to-many relations, we get duplicate rows:

```sql
SELECT o.id, p.id
FROM order o
JOIN order_items oi ON o.id = oi.order_id
JOIN price p ON oi.price_id = p.id;

 order_id | price_id
----------+----------
    45   |    38
    45   |    56    -- Order 45 appears twice!
    70   |    38
    70   |    50    -- Order 70 appears 3 times!
    70   |    77
```

Django can't handle duplicate rows in querysets.

### Solution 1: prefetch_related() (For ManyToMany/Reverse FK)

```python
# ✅ GOOD - Separate queries but cached
orders = Order.objects.prefetch_related('items__program').all()[:100]

# Query 1: Fetch orders
# Query 2: Fetch items for these orders
# Query 3: Fetch programs for these items

for order in orders:
    for item in order.items.all():  # Uses cached data!
        print(item.program.name)  # Uses cached data!
```

**SQL Generated:**
```sql
-- Query 1: Main query
SELECT * FROM order LIMIT 100;

-- Query 2: Prefetch items (with through table)
SELECT price.*, order_items.order_id 
FROM price
INNER JOIN order_items ON price.id = order_items.price_id
WHERE order_items.order_id IN (1, 2, 3, ..., 100);

-- Query 3: Prefetch programs
SELECT * FROM program 
WHERE id IN (8, 15, 23, ..., 67);
```

**Total:** 3 queries for 100 orders with all items and programs! ✅

**When to use:**
- ManyToManyField relationships
- Reverse ForeignKey lookups (e.g., `category.products.all()`)
- When JOIN would create duplicate rows
- "Many-to-many" or "one-to-many" relationships

**How it works:**
1. Executes main query
2. Executes separate queries for related objects
3. Caches results on the objects
4. Subsequent access uses cache (no queries)

### Solution 2: Prefetch Object (Advanced)

For more control over the prefetch query:

```python
from django.db.models import Prefetch

# Customize the prefetch query
active_prices = Price.objects.filter(
    from_date__lte=now,
    to_date__gt=now,
).select_related('program')  # Can combine with select_related!

orders = Order.objects.prefetch_related(
    Prefetch('items', queryset=active_prices, to_attr='active_items')
).all()

# Access prefetched data
for order in orders:
    for item in order.active_items:  # Custom attribute name
        print(item.program.name)
```

**Benefits:**
- Filter the prefetched objects
- Add ordering to prefetched objects
- Combine with `select_related()` on prefetched objects
- Store in custom attribute with `to_attr`
- Multiple prefetches for same relation with different filters

**Example: Multiple prefetches**
```python
Order.objects.prefetch_related(
    Prefetch('items', queryset=Price.objects.filter(active=True), to_attr='active_items'),
    Prefetch('items', queryset=Price.objects.filter(active=False), to_attr='inactive_items'),
)
```

## Critical Warning: Don't Defeat the Cache

```python
# ✅ GOOD - Uses cached data
orders = Order.objects.prefetch_related('items__program')
for order in orders:
    for item in order.items.all():  # Cached!
        print(item.program.name)

# ❌ BAD - Cache ignored, new query!
orders = Order.objects.prefetch_related('items__program')
for order in orders:
    # This creates a NEW query because it's a QuerySet method
    item_names = order.items.values_list('program__name', flat=True)
```

**Rule:** Work on the **cached objects**, not on **new queries**.

## Django Admin Optimization

### Problem: Admin List Display with Related Fields

```python
# ❌ BAD - N+1 in admin
@admin.register(Product)
class ProductAdmin(admin.ModelAdmin):
    list_display = ('id', 'name', 'category')  # N+1!
```

### Solution: list_select_related

```python
# ✅ GOOD - Single query in admin
@admin.register(Product)
class ProductAdmin(admin.ModelAdmin):
    list_display = ('id', 'name', 'category')
    list_select_related = ('category',)  # Uses JOIN
```

### For ManyToMany in Admin

```python
# For ManyToMany, use get_queryset override
@admin.register(Order)
class OrderAdmin(admin.ModelAdmin):
    def get_queryset(self, request):
        qs = super().get_queryset(request)
        return qs.prefetch_related('items__program')
```

## Detecting N+1 Problems

### Method 1: Django Debug Toolbar

```bash
pip install django-debug-toolbar
```

Shows all queries with highlighting for duplicates.

### Method 2: Query Logging

```python
# settings.py
LOGGING = {
    'loggers': {
        'django.db.backends': {
            'level': 'DEBUG',
        },
    },
}
```

Watch console for repeated similar queries.

### Method 3: Count Queries in Code

```python
from django.test.utils import override_settings
from django.db import connection

with override_settings(DEBUG=True):
    connection.queries_log.clear()
    
    # Your code here
    products = Product.objects.all()[:100]
    for p in products:
        print(p.category.name)
    
    print(f"Total queries: {len(connection.queries)}")
```

### Method 4: Asserting in Tests

```python
from django.test import TestCase
from django.db import connection
from django.test.utils import override_settings

class ProductTestCase(TestCase):
    @override_settings(DEBUG=True)
    def test_no_n_plus_one(self):
        # Create test data
        category = Category.objects.create(name='Test')
        for i in range(10):
            Product.objects.create(name=f'Product {i}', category=category)
        
        connection.queries_log.clear()
        
        # The code to test
        products = Product.objects.select_related('category').all()
        for p in products:
            _ = p.category.name
        
        # Should be just 1 query (the select with join)
        self.assertEqual(len(connection.queries), 1)
```

## Performance Comparison

### Scenario: 100 products, each with a category

| Method | Queries | Time (est) |
|--------|---------|------------|
| No optimization | 101 | 500ms |
| `select_related()` | 1 | 5ms |
| **Improvement** | **99% fewer** | **99% faster** |

### Scenario: 100 orders, each with 3 items, each item with program

| Method | Queries | Time (est) |
|--------|---------|------------|
| No optimization | 301 | 1500ms |
| `prefetch_related('items')` | 101 | 500ms |
| `prefetch_related('items__program')` | 3 | 15ms |
| **Improvement** | **99% fewer** | **99% faster** |

## Common Patterns

### Pattern 1: Admin with Related Count

```python
# ❌ BAD - Query per row
@admin.register(Category)
class CategoryAdmin(admin.ModelAdmin):
    list_display = ('name', 'product_count')
    
    def product_count(self, obj):
        return obj.products.count()  # Query!

# ✅ GOOD - Single query with annotation
from django.db.models import Count

@admin.register(Category)
class CategoryAdmin(admin.ModelAdmin):
    list_display = ('name', 'product_count')
    
    def get_queryset(self, request):
        qs = super().get_queryset(request)
        return qs.annotate(product_count=Count('products'))
    
    def product_count(self, obj):
        return obj.product_count  # No query!
    product_count.admin_order_field = 'product_count'
```

### Pattern 2: API Serialization

```python
# ❌ BAD - N+1 in serializer
class ProductSerializer(serializers.ModelSerializer):
    category_name = serializers.CharField(source='category.name')
    
    class Meta:
        model = Product
        fields = ['id', 'name', 'category_name']

# ViewSet without optimization
class ProductViewSet(viewsets.ModelViewSet):
    queryset = Product.objects.all()  # N+1!
    serializer_class = ProductSerializer

# ✅ GOOD - Optimized in ViewSet
class ProductViewSet(viewsets.ModelViewSet):
    queryset = Product.objects.select_related('category')
    serializer_class = ProductSerializer
```

### Pattern 3: Template Rendering

```python
# ❌ BAD - N+1 in template
# views.py
def product_list(request):
    products = Product.objects.all()
    return render(request, 'products.html', {'products': products})

# template: products.html
{% for product in products %}
    {{ product.category.name }}  <!-- Query per product! -->
{% endfor %}

# ✅ GOOD - Prefetch in view
def product_list(request):
    products = Product.objects.select_related('category')
    return render(request, 'products.html', {'products': products})
```

## Advanced Techniques

### Prefetch with Custom QuerySet

```python
# Get orders with only active items
from django.utils import timezone

now = timezone.now()
active_items = Price.objects.filter(
    active=True,
    valid_from__lte=now,
    valid_until__gt=now,
).select_related('program')

orders = Order.objects.prefetch_related(
    Prefetch('items', queryset=active_items, to_attr='active_items')
)
```

### Conditional Prefetch

```python
# Different prefetch based on user
def get_orders(user):
    qs = Order.objects.all()
    
    if user.is_staff:
        # Staff sees all items
        qs = qs.prefetch_related('items__program')
    else:
        # Users see only their own items
        user_items = Price.objects.filter(created_by=user).select_related('program')
        qs = qs.prefetch_related(
            Prefetch('items', queryset=user_items, to_attr='my_items')
        )
    
    return qs
```

### Deep Prefetching

```python
# Multiple levels deep
orders = Order.objects.prefetch_related(
    'items__program__category__parent'
)

# Access without queries
for order in orders:
    for item in order.items.all():
        print(item.program.category.parent.name)  # No queries!
```

## Pitfalls to Avoid

### Pitfall 1: Chaining QuerySets After Prefetch

```python
# ❌ BAD - Defeats prefetch
orders = Order.objects.prefetch_related('items')
for order in orders:
    active_items = order.items.filter(active=True)  # NEW QUERY!
    
# ✅ GOOD - Prefetch filtered items
active_items_qs = Price.objects.filter(active=True)
orders = Order.objects.prefetch_related(
    Prefetch('items', queryset=active_items_qs, to_attr='active_items')
)
for order in orders:
    for item in order.active_items:  # Cached!
        ...
```

### Pitfall 2: Using .count() on Prefetched Relations

```python
# ❌ BAD - count() creates query
orders = Order.objects.prefetch_related('items')
for order in orders:
    count = order.items.count()  # NEW QUERY!

# ✅ GOOD - Use len() on cached list
orders = Order.objects.prefetch_related('items')
for order in orders:
    count = len(order.items.all())  # No query!

# ✅ BETTER - Annotate if you only need count
from django.db.models import Count
orders = Order.objects.annotate(item_count=Count('items'))
for order in orders:
    count = order.item_count  # No query!
```

### Pitfall 3: Accessing Non-Prefetched Relations

```python
# ❌ BAD - Only prefetched items, not programs
orders = Order.objects.prefetch_related('items')
for order in orders:
    for item in order.items.all():
        print(item.program.name)  # N queries for programs!

# ✅ GOOD - Prefetch entire chain
orders = Order.objects.prefetch_related('items__program')
```

## Quick Reference

### When to Use What

```
ForeignKey/OneToOne access?
    → select_related('field')

ManyToMany or reverse FK access?
    → prefetch_related('field')

Need to filter prefetched objects?
    → Prefetch('field', queryset=filtered_qs)

Only need specific fields?
    → values('field1', 'related__field2')
    → values_list('field1', 'related__field2')

Deep nesting?
    → select_related('fk1__fk2__fk3')
    → prefetch_related('m2m1__fk1__m2m2')

Need counts/aggregates?
    → annotate(count=Count('related'))
```

### Debugging Checklist

- [ ] Enable query logging
- [ ] Count queries in view
- [ ] Check for repeated similar queries
- [ ] Look for queries inside loops
- [ ] Verify prefetch is being used (not defeated)
- [ ] Test with realistic data volume (100+ objects)
- [ ] Use django-debug-toolbar in development
- [ ] Add query count assertions in tests
