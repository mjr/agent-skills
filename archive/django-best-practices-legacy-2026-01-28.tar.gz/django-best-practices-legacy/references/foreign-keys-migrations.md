# Foreign Keys and Migrations Best Practices

Source: https://hakibenita.com/django-foreign-keys

## Foreign Key Configuration

### Always Set db_index Explicitly

**Rule:** Never rely on implicit index creation. Always explicitly set `db_index` and add a comment explaining the decision.

```python
# ❌ BAD - Implicit behavior unclear
category = models.ForeignKey(to=Category, on_delete=models.PROTECT)

# ✅ GOOD - Explicit with reasoning
category = models.ForeignKey(
    to=Category,
    on_delete=models.PROTECT,
    related_name='products',
    db_index=False,  # Indexed in unique constraint
)

created_by = models.ForeignKey(
    to=User,
    on_delete=models.PROTECT,
    related_name='+',
    db_index=True,  # Used to speed up user deletion
)
```

**Why:** ForeignKey implicitly creates an index unless `db_index=False`. Making this explicit prevents confusion and documents intent.

### Indexes on Foreign Keys Are Used Indirectly

Foreign key indexes serve two purposes beyond queries:
1. **ON DELETE CASCADE:** Index used to find and delete related objects
2. **ON DELETE PROTECT:** Index used to verify no related objects exist

**Example:** Deleting a user triggers queries like:
```sql
SELECT * FROM "catalog_product" WHERE "created_by_id" IN (102);
```

**Implication:** Even if you never query by a foreign key, the index may be essential for delete operations.

## Unique Constraints

### Use UniqueConstraint Instead of unique_together

```python
# ❌ DEPRECATED
class Meta:
    unique_together = (('category', 'category_sort_order'),)

# ✅ RECOMMENDED
class Meta:
    constraints = [
        models.UniqueConstraint(
            name='product_category_sort_order_uk',
            fields=('category', 'category_sort_order'),
        ),
    ]
```

**Benefits:**
- More functionality than unique_together
- Easier to modify
- Supports advanced B-Tree index features
- unique_together may be deprecated in the future

## Migration Best Practices

### Always Check Generated SQL

**Critical:** Never apply migrations without reviewing the SQL:

```bash
./manage.py sqlmigrate app_name migration_number
```

**Common issues:**
- Django may re-create entire foreign key constraints unnecessarily
- Operations that should be simple can acquire extended locks
- Implicit behavior can cause blocking operations

### Use SeparateDatabaseAndState for Manual Control

When Django generates incorrect SQL for foreign key changes:

```python
migrations.SeparateDatabaseAndState(
    state_operations=[
        # What Django's internal state should reflect
        migrations.AlterField(
            model_name='product',
            name='category',
            field=models.ForeignKey(db_index=False, ...),
        ),
    ],
    database_operations=[
        # What actually runs in the database
        migrations.RunSQL(
            'DROP INDEX CONCURRENTLY catalog_product_category_id_idx',
            'CREATE INDEX CONCURRENTLY catalog_product_category_id_idx ...',
        ),
    ],
)
```

**Use cases:**
- Dropping/creating indexes on foreign keys
- Avoiding unnecessary constraint recreation
- Any time Django's generated SQL is suboptimal

### Use Concurrent Index Operations

```python
class Migration(migrations.Migration):
    atomic = False  # Required for concurrent operations

    operations = [
        migrations.RunSQL(
            'DROP INDEX CONCURRENTLY my_index',
            'CREATE INDEX CONCURRENTLY my_index ON table (column)',
        ),
    ]
```

**Or use built-in operations (PostgreSQL only):**

```python
from django.contrib.postgres.operations import AddIndexConcurrently

class Migration(migrations.Migration):
    atomic = False

    operations = [
        AddIndexConcurrently(
            model_name='product',
            index=models.Index(fields=['field'], name='index_name'),
        ),
    ]
```

**Benefits:**
- Minimal locking during index operations
- Safe for production systems under load

**Trade-offs:**
- Takes longer than regular index operations
- Cannot be executed in atomic transactions
- If migration fails mid-execution, state may be inconsistent

### Provide Reverse Operations

Always provide reverse SQL for RunSQL operations:

```python
migrations.RunSQL(
    'DROP INDEX CONCURRENTLY my_index',
    reverse_sql='CREATE INDEX CONCURRENTLY my_index ON table (column)',
)
```

**Why:** You never know when you'll need to rollback.

### Order Migration Operations Strategically

```python
# ❌ BAD - System left without index if migration fails
operations = [
    # Drop old index
    migrations.RunSQL('DROP INDEX old_index'),
    # Create new index
    AddIndexConcurrently(...),
]

# ✅ GOOD - Always have at least one index
operations = [
    # Create new index first
    AddIndexConcurrently(...),
    # Then drop old index
    migrations.RunSQL('DROP INDEX old_index'),
]
```

**Principle:** Create before drop to minimize impact on running systems.

### Move Non-Atomic Operations to Separate Migrations

```python
# Migration 0001 - Atomic operations
class Migration(migrations.Migration):
    operations = [
        migrations.AddField(...),
        migrations.AlterField(...),
    ]

# Migration 0002 - Concurrent operations
class Migration(migrations.Migration):
    atomic = False
    
    operations = [
        AddIndexConcurrently(...),
    ]
```

**Why:** Reduces risk of incomplete migrations leaving system in inconsistent state.

## Partial Indexes for Nullable Foreign Keys

Use partial indexes when a foreign key is mostly NULL:

```python
class Meta:
    indexes = [
        models.Index(
            name='product_last_edited_by_part_ix',
            fields=('last_edited_by',),
            condition=models.Q(last_edited_by__isnull=False),
        ),
    ]

last_edited_by = models.ForeignKey(
    to=User,
    on_delete=models.PROTECT,
    null=True,
    db_index=False,  # Indexed in Meta
)
```

**When to use:**
- Foreign key is nullable
- Most rows have NULL value (>90%)
- You only care about non-NULL rows

**Benefits:**
- Can reduce index size by 90%+ 
- Faster index operations
- Lower storage costs

**Important:** NULL values ARE indexed in PostgreSQL (unlike Oracle). Don't assume they aren't.

## Locking Best Practices

### Always Specify Tables to Lock

```python
# ❌ BAD - Locks all joined tables
Product.objects.select_related('created_by').select_for_update().get(id=1)

# ✅ GOOD - Only locks the product
Product.objects.select_related('created_by').select_for_update(of=('self',)).get(id=1)
```

**Why:** `select_for_update()` by default locks ALL tables in the query, including joined tables. This can cause unexpected blocking.

### Use no_key=True When Not Updating Keys

```python
# When you won't update primary keys or unique constraints
product = (
    Product.objects
    .select_related('created_by')
    .select_for_update(of=('self',), no_key=True)
    .get(id=1)
)
```

**Benefits:**
- More permissive lock (FOR NO KEY UPDATE)
- Allows other transactions to insert rows referencing this row
- Prevents blocking when creating related objects

**When to use:**
- You're only updating regular columns
- You're NOT changing primary keys
- You're NOT changing unique constraints referenced by foreign keys

**Example impact:**
```python
# Session 1: Updating product (with no_key=True)
with transaction.atomic():
    product = Product.objects.select_for_update(
        of=('self',), 
        no_key=True
    ).get(id=1)
    product.name = "New name"
    product.save()
    # Long-running transaction...

# Session 2: Creating order that references product
# ✅ This works! no_key=True allows it
Order.objects.create(product_id=1, ...)
```

Without `no_key=True`, Session 2 would block until Session 1 completes.
