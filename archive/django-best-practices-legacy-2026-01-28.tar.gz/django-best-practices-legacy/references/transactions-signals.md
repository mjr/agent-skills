# Database Transactions and Signals Best Practices

Sources:
- https://hakibenita.com/django-nested-transaction
- https://hakibenita.com/django-reliable-signals

## Nested Transactions Pitfalls

### The Problem: Hidden Nesting

```python
# Function A
def mark_paid(pk: int):
    with transaction.atomic():
        payout = Payout.objects.get(pk=pk)
        payout.status = 'paid'
        payout.save()
    
    # Signal sent AFTER transaction commits
    signals.payout_paid.send_robust(payout=payout)

# Function B (calling Function A)
def bulk_mark_paid(payout_ids: list[int]):
    with transaction.atomic():  # Outer transaction
        for pk in payout_ids:
            mark_paid(pk)  # Inner transaction!
```

**What happens:**
1. Outer transaction starts
2. For each payout: inner transaction commits, signal fires
3. If ANY payout fails: outer transaction rolls back
4. **Result:** Signals were sent, but data was rolled back! 💥

**Real impact:** Users got "You've been paid!" notifications, but payments were rolled back.

### Solution 1: Assert Transaction State

```python
from django.db import connection

def assert_is_not_in_atomic_block():
    assert not connection.in_atomic_block, (
        'This function must not be run inside a DB transaction.'
    )

def mark_paid(pk: int):
    assert_is_not_in_atomic_block()  # Fail fast!
    
    with transaction.atomic():
        payout = Payout.objects.get(pk=pk)
        payout.status = 'paid'
        payout.save()
    
    signals.payout_paid.send_robust(payout=payout)
```

**Trade-off:** Tests run in transactions, so you need to patch these functions:

```python
@pytest.fixture(scope='session', autouse=True)
def patch_atomic_checks():
    with mock.patch('myapp.db.assert_is_in_atomic_block'), \
         mock.patch('myapp.db.assert_is_not_in_atomic_block'):
        yield
```

### Solution 2: Durable Transactions (Django 3.2+)

```python
def mark_paid(pk: int):
    with transaction.atomic(durable=True):  # Can't be nested!
        payout = Payout.objects.get(pk=pk)
        payout.status = 'paid'
        payout.save()
    
    signals.payout_paid.send_robust(payout=payout)
```

**Behavior:**
```python
with transaction.atomic():
    with transaction.atomic(durable=True):
        pass
# RuntimeError: A durable atomic block cannot be nested
```

**Trade-offs:**
- Makes bulk operations impossible or complicated
- Less flexible than assertion approach
- Clear error message at runtime

### Solution 3: on_commit (Recommended)

```python
def mark_paid(pk: int):
    with transaction.atomic():
        payout = Payout.objects.get(pk=pk)
        payout.status = 'paid'
        payout.save()
        
        # Only fire signal when transaction actually commits
        transaction.on_commit(
            lambda: signals.payout_paid.send_robust(payout=payout)
        )
```

**Benefits:**
- Works inside nested transactions
- Signal only fires on successful commit
- If outer transaction rolls back, signal doesn't fire
- Most flexible solution

**Testing consideration:**
```python
# Django TestCase
def test_signal_fires(self):
    with self.captureOnCommitCallbacks(execute=True):
        mark_paid(pk=1)
    assert signal_was_called

# pytest-django (requires pytest-django 4.4+)
def test_signal_fires(django_capture_on_commit_callbacks):
    with django_capture_on_commit_callbacks(execute=True):
        mark_paid(pk=1)
    assert signal_was_called
```

## Django Signals Best Practices

### Signal Reliability Issues

Django signals are **NOT reliable** by default:

1. **No guaranteed delivery:** If server crashes during signal dispatch, some receivers may never execute
2. **No retry mechanism:** Failed receivers just fail silently (with `send_robust`)
3. **Blocking execution:** Receivers execute synchronously in sender's thread
4. **Transaction coupling:** Easy to violate transaction boundaries

### Decoupling Modules with Signals

**Good use case:**

```python
# Low-level module (payout)
class PayoutProcess(models.Model):
    @classmethod
    def mark_paid(cls, pk: int):
        with transaction.atomic():
            payout = cls.objects.get(pk=pk)
            payout.status = 'paid'
            payout.save()
        
        signals.payout_paid.send_robust(sender=cls, payout=payout)

# High-level module (merchants) - depends on payout
@receiver(signals.payout_paid)
def notify_merchant(sender, payout):
    # Check if this is a merchant payout
    try:
        merchant_payout = MerchantPayout.objects.get(payout=payout)
    except MerchantPayout.DoesNotExist:
        return
    
    merchant_payout.user.email_user(f'You got paid ${payout.amount}!')
```

**Why this works:**
- Low-level module doesn't depend on high-level modules
- Avoids circular dependencies
- Multiple apps can react to same signal

### Signal Naming Convention

```python
# ❌ BAD - Implies intent (creates coupling)
order_completed = Signal()

# ✅ GOOD - Describes what happened (neutral)
payment_succeeded = Signal()
```

**Principle:** Signal names should describe events, not intentions. This keeps sender independent of how receivers use the signal.

### send() vs send_robust()

```python
# send() - Exceptions propagate to sender
signals.my_signal.send(sender=self, data=data)
# If any receiver fails → sender fails

# send_robust() - Exceptions caught and returned
responses = signals.my_signal.send_robust(sender=self, data=data)
# Sender continues even if receivers fail
```

**When to use send_robust():**
- Module decoupling is priority
- Sender shouldn't be affected by receiver failures
- Non-critical side effects

**When to use send():**
- Receiver actions are critical
- You want sender to know about failures
- Tight coupling is acceptable

### Signals and Transactions

#### Problem: Signals Inside Transactions

```python
with transaction.atomic():
    obj.status = 'completed'
    obj.save()
    
    signals.completed.send_robust(obj=obj)
    # Issues:
    # 1. Receivers execute inside transaction (extends duration)
    # 2. If transaction rolls back, side effects already happened
    # 3. Receivers' own transactions become nested
```

#### Solution: Use on_commit

```python
with transaction.atomic():
    obj.status = 'completed'
    obj.save()
    
    transaction.on_commit(
        lambda: signals.completed.send_robust(obj=obj)
    )
```

**Benefits:**
- Signal only fires after commit
- Receivers not part of sender's transaction
- Safe for side effects

### Reliable Signals Pattern (Advanced)

For mission-critical workflows, use background tasks:

```python
# 1. Define signal
from reliable_signal import Signal  # Custom implementation
completed = Signal()

# 2. Send signal in transaction
with transaction.atomic():
    obj.save()
    # Enqueue task for each receiver
    completed.send_reliable(sender=self, obj=obj)

# 3. Workers execute receivers as tasks
# - At-least-once delivery
# - Automatic retries
# - Survives crashes
```

**When to use:**
- Payment processing
- Critical notifications
- Audit logs
- Any workflow where signal delivery MUST happen

**Trade-offs:**
- Requires task queue infrastructure
- Added complexity
- Slight delay in execution

## Transaction Best Practices Summary

### DO:

```python
# ✅ Use on_commit for side effects
with transaction.atomic():
    obj.save()
    transaction.on_commit(lambda: send_email())

# ✅ Keep transactions short
with transaction.atomic():
    obj.save()  # Quick database operation
# Side effects outside transaction
send_email()

# ✅ Document transaction requirements
def process_payment():
    """Must be called outside of transaction."""
    assert_is_not_in_atomic_block()
```

### DON'T:

```python
# ❌ Don't send signals inside transactions
with transaction.atomic():
    obj.save()
    signals.saved.send(obj=obj)  # Receivers in transaction!

# ❌ Don't do slow work in transactions
with transaction.atomic():
    obj.save()
    send_email()  # Network call in transaction!
    call_external_api()  # Even worse!

# ❌ Don't assume transactions auto-commit
def my_function():
    obj.save()
    signals.saved.send(obj=obj)
# If caller wraps this in transaction.atomic(), signal fires early!
```

### Testing Patterns

```python
# Test with on_commit
from django.test import TestCase

class MyTest(TestCase):
    def test_signal_fires_on_commit(self):
        with self.captureOnCommitCallbacks(execute=True):
            process_payment(pk=1)
        
        assert notification_sent
        
# Test for transaction requirements  
def test_requires_no_transaction():
    with transaction.atomic():
        with pytest.raises(AssertionError):
            process_payment(pk=1)
```

## Common Pitfalls

### Pitfall 1: Forgetting on_commit in Bulk Operations

```python
# ❌ DANGEROUS
def bulk_process(ids):
    with transaction.atomic():
        for id in ids:
            process_one(id)  # This sends signal!
            # Signal fires immediately, but transaction might rollback
```

**Fix:**
```python
# ✅ SAFE
def process_one(id):
    with transaction.atomic():
        obj.save()
        transaction.on_commit(lambda: signals.processed.send(obj=obj))
```

### Pitfall 2: Assuming Signals Are Reliable

```python
# ❌ DANGEROUS - Signal might not fire if server crashes
with transaction.atomic():
    payment.status = 'completed'
    payment.save()
signals.payment_completed.send(payment=payment)
# If server crashes here, no notification sent!
```

**Fix:** Use task queue for critical workflows:
```python
with transaction.atomic():
    payment.save()
    transaction.on_commit(
        lambda: send_notification_task.delay(payment.id)
    )
```

### Pitfall 3: N+1 Queries in Signal Receivers

```python
# ❌ SLOW - N queries in receiver
@receiver(payout_completed)
def notify_users(sender, payout):
    merchant = MerchantPayout.objects.get(payout=payout)
    # Receiver for each payout does a query!
```

**Fix:** Optimize or add context to signal:
```python
# ✅ Better - Include context in signal
signals.payout_completed.send(
    sender=cls,
    payout=payout,
    merchant_id=merchant_id  # Avoid query
)
```
