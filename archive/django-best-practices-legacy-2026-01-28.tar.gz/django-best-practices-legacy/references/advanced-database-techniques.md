# Advanced Database Techniques and Tips

Sources:
- https://hakibenita.com/9-django-tips-for-working-with-databases
- https://hakibenita.com/how-to-use-grouping-sets-in-django

## Statement Timeout (Critical!)

### The Problem

Django uses synchronous workers. A long-running query blocks a worker process, making it unavailable to other users.

### Solution: Set Global Timeout

```python
# wsgi.py
from django.db.backends.signals import connection_created
from django.dispatch import receiver

@receiver(connection_created)
def setup_postgres(connection, **kwargs):
    if connection.vendor != 'postgresql':
        return
    
    # Timeout statements after 30 seconds
    with connection.cursor() as cursor:
        cursor.execute("SET statement_timeout TO 30000;")
```

**Why wsgi.py?**
- Only affects worker processes
- Doesn't affect management commands, analytics, cron jobs

**Alternative: User-level timeout**
```sql
ALTER USER app_user SET statement_timeout TO 30000;
```

**Important:** Also set timeouts on external API calls:
```python
import requests

response = requests.get(
    'https://api.slow-service.com',
    timeout=3.0  # Always set timeout!
)
```

## Aggregation with Filter (Django 2.0+)

### Old Way (Before Django 2.0)

```python
from django.db.models import Count, Sum, Case, When, Value, IntegerField

User.objects.aggregate(
    total_users=Count('id'),
    total_active_users=Sum(Case(
        When(is_active=True, then=Value(1)),
        default=Value(0),
        output_field=IntegerField(),
    )),
)
```

### New Way (Django 2.0+)

```python
from django.db.models import Count, Q

User.objects.aggregate(
    total_users=Count('id'),
    total_active_users=Count('id', filter=Q(is_active=True)),
)
```

**SQL Generated (PostgreSQL):**
```sql
-- Old way
SELECT
    COUNT(id) AS total_users,
    SUM(CASE WHEN is_active THEN 1 ELSE 0 END) AS total_active_users
FROM auth_users;

-- New way
SELECT
    COUNT(id) AS total_users,
    COUNT(id) FILTER (WHERE is_active) AS total_active_users
FROM auth_users;
```

**Benefits:**
- Cleaner, more readable code
- Uses native SQL `FILTER (WHERE ...)` clause
- Better performance in some cases

## Named Tuples from QuerySets (Django 2.0+)

```python
# Regular tuples
user_data = User.objects.values_list('first_name', 'last_name')[0]
# ('Haki', 'Benita')

# Named tuples
user_data = User.objects.values_list(
    'first_name',
    'last_name',
    named=True
)[0]
# Row(first_name='Haki', last_name='Benita')

# Access by name
print(user_data.first_name)  # 'Haki'
print(user_data.last_name)   # 'Benita'
```

**Benefits:**
- More readable code
- Self-documenting
- IDE autocomplete support
- Type hints work better

## Custom Database Functions

### The Problem

PostgreSQL doesn't support all functions on all data types.

**Example:** STDDEV on interval fields:

```python
from django.db.models import Avg, StdDev

Report.objects.aggregate(
    avg_duration=Avg('duration'),
    std_duration=StdDev('duration'),
)
# ProgrammingError: function stddev_pop(interval) does not exist
```

### Solution: Custom Func Expression

```python
# common/db.py
from django.db.models import Func

class Epoch(Func):
    function = 'EXTRACT'
    template = "%(function)s('epoch' from %(expressions)s)"
```

**Usage:**
```python
from django.db.models import Avg, StdDev, F
from common.db import Epoch

Report.objects.aggregate(
    avg_duration=Avg('duration'),
    std_duration=StdDev(Epoch(F('duration'))),
)
# {'avg_duration': timedelta(0, 0, 55432), 'std_duration': 1.06310113695549}
```

**SQL Generated:**
```sql
SELECT
    AVG(duration),
    STDDEV_POP(EXTRACT('epoch' FROM duration))
FROM report;
```

### Common Custom Functions

```python
# Extract parts from datetime
class ExtractDay(Func):
    function = 'EXTRACT'
    template = "%(function)s(DAY from %(expressions)s)"

class ExtractMonth(Func):
    function = 'EXTRACT'
    template = "%(function)s(MONTH from %(expressions)s)"

# String manipulation
class Upper(Func):
    function = 'UPPER'

class Lower(Func):
    function = 'LOWER'

# Date truncation
class DateTrunc(Func):
    function = 'DATE_TRUNC'
    # template = "%(function)s('day', %(expressions)s)"
```

## LIMIT with Safety Check

### The Problem

Users requesting "all data" can overwhelm the system.

### Wrong Approach

```python
# ❌ BAD - Fetches ALL rows then slices
data = list(Sale.objects.all())[:100]
```

### Better but Incomplete

```python
# ✅ Better - LIMIT in SQL
data = Sale.objects.all()[:100]
```

**Problem:** User thinks there are only 100 sales when there might be millions!

### Best Approach: LIMIT + 1 Trick

```python
LIMIT = 100

# Fetch LIMIT + 1 rows
data = Sale.objects.all()[:(LIMIT + 1)]

# Check if there are more rows
if len(data) > LIMIT:
    raise ExceededLimit(LIMIT)

# Return only LIMIT rows
return data[:LIMIT]
```

**How it works:**
- Fetch 101 rows
- If 101st row exists → there are more than 100 rows
- Raise error to inform user
- Otherwise, return the data

**Benefits:**
- No extra COUNT query
- User knows data was truncated
- Only one additional row fetched

**Alternative:** Show warning instead of error:
```python
LIMIT = 100
data = Sale.objects.all()[:(LIMIT + 1)]
has_more = len(data) > LIMIT

return {
    'data': data[:LIMIT],
    'has_more': has_more,
    'total_fetched': min(len(data), LIMIT),
}
```

## Foreign Key Index Management

### Implicit Index Creation

```python
# Django automatically creates index on ForeignKey
class Product(models.Model):
    category = models.ForeignKey(Category, on_delete=models.PROTECT)
    # Index on category_id is created automatically!
```

### When to Disable FK Indexes

**Scenario 1: Already covered by composite index**

```python
class Membership(models.Model):
    group = models.ForeignKey(Group, db_index=False)
    user = models.ForeignKey(User, db_index=False)
    
    class Meta:
        # This creates index on (user, group)
        # Don't need separate indexes on group and user!
        unique_together = (('user', 'group'),)
```

**Result:** 1 index instead of 3

**Scenario 2: Rarely queried, but CASCADE/PROTECT used**

```python
# Keep index if ON DELETE CASCADE/PROTECT
# Index used to find/delete related objects
created_by = models.ForeignKey(
    User,
    on_delete=models.PROTECT,
    db_index=True,  # Used when deleting users
)
```

## Index Column Order in Composite Indexes

### B-Tree Structure

B-Tree composite indexes:
1. First column creates a tree
2. Each leaf creates a tree for second column
3. Each second-level leaf creates tree for third column...

**Order matters!**

### Rule of Thumb

**Put high-cardinality columns first.**

High cardinality = more distinct values

```python
# ❌ BAD - Low cardinality first
class Membership(models.Model):
    class Meta:
        unique_together = (('group', 'user'),)
        # Few groups, many users
        # Creates large secondary index
```

```python
# ✅ GOOD - High cardinality first  
class Membership(models.Model):
    class Meta:
        unique_together = (('user', 'group'),)
        # Many users, few groups
        # Creates smaller secondary index
```

**Why?**
- More users than groups
- Putting `user` first makes second-level index (on `group`) smaller
- Faster lookups, less storage

**Caveat:** Optimize for your actual query patterns!

## BRIN Indexes (PostgreSQL)

### What is BRIN?

**BRIN = Block Range Index**

Instead of indexing individual values, BRIN indexes ranges of blocks.

**Structure:**
```
Blocks:     [1,2,3], [4,5,6], [7,8,9]
BRIN Index: [1-3],   [4-6],   [7-9]
```

**Search for value 5:**
- [1-3] → Definitely not here ❌
- [4-6] → **Might be here** ✅
- [7-9] → Definitely not here ❌

Only read blocks 4-6!

### When BRIN Works Well

**Critical requirement:** Values must be **naturally sorted on disk**

**Example: auto_now_add fields**

```python
class SomeModel(models.Model):
    created = DateTimeField(auto_now_add=True)
    # Values inserted in chronological order
    # Naturally sorted on disk!
```

### BRIN vs B-Tree

**Table with ~2M rows:**
- B-Tree index: **37 MB**
- BRIN index: **49 KB**

**That's 99.87% smaller!**

### Creating BRIN Index in Django

```python
from django.contrib.postgres.indexes import BrinIndex

class SomeModel(models.Model):
    created = DateTimeField(auto_now_add=True)
    
    class Meta:
        indexes = (
            BrinIndex(fields=['created']),
        )
```

### When NOT to Use BRIN

**Example with random data:**
```
Blocks:     [2,9,5], [1,4,7], [3,8,6]
BRIN Index: [2-9],   [1-7],   [3-8]
```

**Search for 5:**
- [2-9] → Might be here ✅
- [1-7] → Might be here ✅
- [3-8] → Might be here ✅

Index is useless! Must scan entire table.

**Use BRIN when:**
- ✅ Values naturally sorted (created_at, sequential IDs)
- ✅ Very large tables
- ✅ Range queries common
- ✅ Storage is a concern

**Don't use BRIN when:**
- ❌ Random data distribution
- ❌ Frequent updates (breaks sorting)
- ❌ Need exact lookups only
- ❌ Small tables

## Advanced Aggregation with GROUPING SETS

### The Problem

Dashboard needs:
1. Metrics by merchant and device
2. Summary line (totals)

**Naive approach: 2 queries**

```python
# Query 1: By merchant and device (~30s)
results = Sale.objects.values('merchant', 'device').annotate(
    total=Count('id'),
    avg_amount=Avg('charged_amount'),
    unique_users=Count('user', distinct=True),
)

# Query 2: Summary (~30s)  
summary = Sale.objects.aggregate(
    total=Count('id'),
    avg_amount=Avg('charged_amount'),
    unique_users=Count('user', distinct=True),
)

# Total time: ~60 seconds!
```

### Solution: GROUPING SETS

**Single query with multiple aggregation levels:**

```sql
SELECT
    merchant,
    device,
    COUNT(id) AS total,
    AVG(charged_amount) AS avg_amount,
    COUNT(DISTINCT user_id) AS unique_users
FROM sale
GROUP BY GROUPING SETS (
    (merchant, device),  -- Detail rows
    ()                    -- Summary row
);
```

**Result:**
```
merchant | device | total | avg_amount | unique_users
---------+--------+-------+------------+-------------
Walmart  | D1     |   2   |    77.00   |      1
Walmart  | D2     |   3   |    17.00   |      3
Costco   | D1     |   3   |   112.33   |      3
         |        |  13   |    70.46   |      5  ← Summary
```

**Time: ~30 seconds** (50% improvement!)

### GROUPING SETS Variations

#### ROLLUP

Aggregates "upward" through hierarchy:

```sql
SELECT device, merchant, COUNT(*)
FROM sale
GROUP BY ROLLUP(device, merchant);
```

**Groups created:**
1. `()` - All
2. `(device, merchant)` - Most detailed
3. `(device)` - Intermediate

**Order matters!** Flip to get different groupings.

#### CUBE

All possible combinations:

```sql
SELECT device, merchant, COUNT(*)
FROM sale
GROUP BY CUBE(device, merchant);
```

**Groups created:**
1. `()` - All
2. `(device, merchant)` - Both
3. `(device)` - Device only
4. `(merchant)` - Merchant only

#### GROUPING SETS (Most Flexible)

Specify exact groups needed:

```sql
SELECT merchant, device, COUNT(*)
FROM sale  
GROUP BY GROUPING SETS (
    (merchant, device),
    (merchant),
    ()
);
```

### Equivalence Table

| Expression | Equivalent GROUPING SETS |
|------------|-------------------------|
| `ROLLUP(a, b)` | `GROUPING SETS ((a,b), (a), ())` |
| `CUBE(a, b)` | `GROUPING SETS ((a,b), (a), (b), ())` |

### Using GROUPING SETS in Django

**Challenge:** Django doesn't support GROUPING SETS natively.

**Solution:** Manipulate the generated SQL

```python
import re
from django.db import connection

# Get base queryset
qs = Sale.objects.values('merchant', 'device').annotate(
    total=Count('id'),
    avg_amount=Avg('charged_amount'),
)

# Extract SQL and params
sql, params = qs.query.sql_with_params()

# Modify SQL to add GROUPING SETS
sql_with_grouping_sets = re.sub(
    r'GROUP BY (.*) ORDER',
    r'GROUP BY GROUPING SETS ((\1), ()) ORDER',
    sql,
)

# Execute modified query
with connection.cursor() as cursor:
    cursor.execute(sql_with_grouping_sets, params)
    results = cursor.fetchall()
```

**Results:**
```python
[
    ('Walmart', 'D1', 2, 77.0),
    ('Walmart', 'D2', 3, 17.0),
    ('Costco', 'D1', 3, 112.33),
    (None, None, 13, 70.46),  # ← Summary row
]
```

### Deterministic Sort Order

```python
# Make summary row appear first
qs = qs.order_by(
    F('merchant').desc(nulls_first=True)
)
```

**nulls_first options:**
- `nulls_first=True` → Summary row first
- `nulls_last=True` → Summary row last

### Important Warnings

**⚠️ This is fragile!**

```python
# DON'T DO THIS IN PRODUCTION (usually)
```

**Why it's risky:**
- Uses undocumented internal API (`qs.query.sql_with_params()`)
- Can break in Django updates
- Regex manipulation is brittle
- Hard to maintain

**When it's acceptable:**
- Internal admin pages only
- Performance is critical
- You understand the risks
- You have good tests
- You monitor Django updates

**Better alternatives:**
- Use raw SQL explicitly
- Create database views
- Use stored procedures
- Wait for Django to support it natively

### Advanced Usage: Combining with Filters

```python
from django.utils import timezone

# Works with date filters from Django Admin
qs = Sale.objects.filter(
    sold_at__gte=timezone.now() - timedelta(days=30)
).values('merchant', 'device').annotate(
    total=Count('id'),
)

# Modify SQL as before
sql, params = qs.query.sql_with_params()
# ... regex substitution ...

# Params are passed correctly!
with connection.cursor() as cursor:
    cursor.execute(sql_with_grouping_sets, params)
    results = cursor.fetchall()
```

## Raw SQL Best Practices

### When to Use Raw SQL

**Use raw SQL when:**
- Django ORM can't express the query
- Performance is critical
- Need database-specific features
- Query is complex and ORM makes it worse

**Don't use raw SQL when:**
- ORM can handle it easily
- You lose model instances
- You need portability
- Team isn't familiar with SQL

### Safe Raw SQL Execution

```python
from django.db import connection

# ✅ GOOD - Parameterized
with connection.cursor() as cursor:
    cursor.execute(
        "SELECT * FROM sales WHERE amount > %s",
        [100]  # Parameters
    )
    results = cursor.fetchall()

# ❌ BAD - SQL Injection risk!
amount = request.GET.get('amount')
cursor.execute(f"SELECT * FROM sales WHERE amount > {amount}")
```

### Using .raw() for Model Instances

```python
# Returns model instances from raw SQL
products = Product.objects.raw('''
    SELECT * FROM product
    WHERE price > %s
    ORDER BY created_at DESC
''', [100])

for product in products:
    print(product.name)  # Full model instance!
```

### Extracting SQL from QuerySet

```python
# Get the SQL Django would execute
qs = Product.objects.filter(price__gt=100)

# Method 1: String representation (not safe to execute)
print(qs.query)

# Method 2: SQL with parameters (safe to execute)
sql, params = qs.query.sql_with_params()
```

## Performance Monitoring

### Query Counting in Development

```python
from django.test.utils import override_settings
from django.db import connection, reset_queries

@override_settings(DEBUG=True)
def my_view(request):
    reset_queries()
    
    # Your code here
    products = Product.objects.all()
    
    print(f"Queries executed: {len(connection.queries)}")
    for query in connection.queries:
        print(query['sql'])
```

### Django Debug Toolbar

```bash
pip install django-debug-toolbar
```

**Features:**
- Shows all queries
- Highlights duplicates (N+1!)
- Shows execution time
- Explains queries
- Shows cache hits

### Query Logging in Production

```python
# settings.py
LOGGING = {
    'handlers': {
        'file': {
            'class': 'logging.FileHandler',
            'filename': 'queries.log',
        },
    },
    'loggers': {
        'django.db.backends': {
            'level': 'DEBUG',
            'handlers': ['file'],
        },
    },
}
```

**Warning:** Can generate huge logs in production!

### Slow Query Detection

```python
# settings.py (PostgreSQL)
LOGGING = {
    'loggers': {
        'django.db.backends': {
            'level': 'DEBUG',
            'filters': ['slow_queries'],
        },
    },
    'filters': {
        'slow_queries': {
            '()': 'path.to.SlowQueryFilter',
        },
    },
}

# Custom filter
class SlowQueryFilter:
    def filter(self, record):
        duration = record.duration
        return duration > 1.0  # Log queries > 1 second
```

## Quick Reference

### Index Types Comparison

| Type | Size | Best For | Avoid When |
|------|------|----------|------------|
| B-Tree | Medium-Large | Unique, ranges, sorting | Very large tables |
| BRIN | Tiny | Sequential data, ranges | Random data |
| Hash | Medium | Equality only | Ranges, sorting |
| GiST | Large | Full-text, geometric | Simple lookups |
| GIN | Large | Arrays, JSONB, full-text | Frequent updates |

### Aggregation Functions Quick Guide

```python
from django.db.models import *

# Counting
Count('id')                          # Total count
Count('field', distinct=True)        # Unique count
Count('id', filter=Q(active=True))  # Conditional count

# Math
Sum('amount')
Avg('price')
Max('score')
Min('date')
StdDev('value')  # Standard deviation
Variance('value')

# Custom
Func('field', function='CUSTOM_SQL_FUNCTION')
```

### When to Use What

```
Need totals/counts at multiple levels?
    → GROUPING SETS / ROLLUP / CUBE

Simple foreign key access?
    → select_related()

Many-to-many or reverse FK?
    → prefetch_related()

Sequential/time-based data on huge table?
    → BRIN index

Random access on reasonable table?
    → B-Tree index

Need database-specific feature?
    → Custom Func or raw SQL

Worried about long queries?
    → Set statement_timeout
```
