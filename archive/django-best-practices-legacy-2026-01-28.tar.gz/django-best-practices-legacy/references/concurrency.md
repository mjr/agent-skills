# Concurrency Handling Best Practices

Source: https://hakibenita.com/django-concurrency

## Core Principles

### Three Common Concurrency Mistakes

1. **Failing to recognize concurrency issues** - Most common mistake
2. **Dismissing issues due to low probability** - "What are the chances..."
3. **Overusing locks** - Locks slow down systems and cause contention

**Golden Rule:** Always assume multiple processes can execute code simultaneously.

## Time-of-Check to Time-of-Use (TOCTOU)

### The Problem

```python
# ❌ BAD - Race condition
if not Model.objects.filter(key=key).exists():
    # Another process can insert here!
    Model.objects.create(key=key, ...)
```

**Scenario:**
1. Process A checks key doesn't exist ✅
2. Process B checks key doesn't exist ✅  
3. Process B creates object with key
4. Process A tries to create object with same key 💥

**Timeline:**
```
Process 1              Process 2              Database
Check key -> ✅
                       Check key -> ✅
                       Create key             key exists
Create key 💥          
```

### Solutions

#### 1. Ask for Forgiveness (EAFP - Pythonic)

```python
# ✅ GOOD - Let database enforce uniqueness
while True:
    key = generate_random_key()
    try:
        return Model.objects.create(key=key, ...)
    except IntegrityError:
        continue  # Try another key
```

**Benefits:**
- No locks needed
- Pythonic approach (Easier to Ask for Forgiveness than Permission)
- Database enforces constraints

**PostgreSQL caveat:** Use nested transaction to handle IntegrityError:

```python
while True:
    key = generate_random_key()
    try:
        with transaction.atomic():  # Nested transaction for PostgreSQL
            return Model.objects.create(key=key, ...)
    except IntegrityError:
        continue
```

#### 2. Lock When Necessary

```python
# When EAFP doesn't work, use locks
with transaction.atomic():
    obj = Model.objects.select_for_update().get(id=id)
    obj.counter += 1
    obj.save()
```

## Race Conditions in Updates

### The Problem

```python
# ❌ BAD - Counter can get out of sync
shorturl = ShortUrl.objects.get(key=key)
shorturl.hits += 1  # Based on stale value!
shorturl.save()
```

**Scenario with 2 concurrent hits:**
```
Process 1         Process 2         Actual Hits
Get hits=0
                  Get hits=0
Update hits=1                       1
                  Update hits=1     1 (should be 2!)
```

### Solutions (in order of preference)

#### 1. F() Expressions (Best - No Locks)

```python
# ✅ BEST - Update relative to database value
from django.db.models import F

shorturl = ShortUrl.objects.get(key=key)
shorturl.hits = F('hits') + 1
shorturl.save(update_fields=['hits'])
```

**SQL generated:**
```sql
UPDATE shorturl SET hits = hits + 1 WHERE id = 154;
```

**Benefits:**
- No locks
- No race conditions
- Concurrent updates work correctly
- Fast

**Caveat:** The returned object's `hits` attribute won't reflect the new value. Refresh if needed:
```python
shorturl.refresh_from_db()
```

#### 2. UPDATE with RETURNING (PostgreSQL/SQLite)

```python
# ✅ GOOD - Single query, returns updated value
shorturl = ShortUrl.objects.raw('''
    UPDATE shorturl_shorturl
    SET hits = hits + 1
    WHERE key = %s
    RETURNING *
''', [key])[0]
```

**Benefits:**
- Single database round trip
- Returns updated instance
- No locks needed

**When to use:**
- You need the updated value immediately
- PostgreSQL or SQLite database
- Performance is critical

#### 3. Select For Update (When You Must Lock)

```python
# ✅ Acceptable but slower - Explicit lock
with transaction.atomic():
    shorturl = (
        ShortUrl.objects
        .select_for_update()
        .get(key=key)
    )
    shorturl.hits += 1
    shorturl.save()
```

**When to use:**
- Complex update logic that can't use F()
- Multiple fields need consistent updates
- Business logic requires current value

**Trade-offs:**
- Serializes access (one at a time)
- Can cause contention under load
- Use as last resort

## Locking Strategies

### Where to Lock

**The Lowest Common Denominator:** The Database

```
Multiple Servers
    └─> Multiple Processes per Server
        └─> Multiple Threads per Process
            └─> DATABASE (only shared resource)
```

**Why not lock elsewhere?**
- Python locks: Only work within one process
- OS locks: Only work on one server  
- App-level locks: Don't work across apps
- Database locks: Work everywhere

### Lock Granularity

```python
# ❌ TERRIBLE - Locks entire table
with connection.cursor() as cursor:
    cursor.execute('LOCK TABLE my_table IN EXCLUSIVE MODE')
    # ... work ...
```

**Problems:**
- All other operations block
- System grinds to halt under load
- Should almost never be used

```python
# ✅ BETTER - Lock specific row
with transaction.atomic():
    obj = Model.objects.select_for_update().get(id=id)
    # ... work ...
```

**Better but:**
- Still serializes access to this row
- Can still cause bottlenecks

```python
# ✅ BEST - No lock, F() expression
obj = Model.objects.get(id=id)
obj.counter = F('counter') + 1
obj.save(update_fields=['counter'])
```

## Avoiding Locks

### Pattern: Increment in Database

```python
# Instead of:
obj.counter += 1  # ❌ Based on stale value

# Do:
obj.counter = F('counter') + 1  # ✅ Database computes
```

### Pattern: Optimistic Locking

```python
# Add version field
class Model(models.Model):
    version = models.IntegerField(default=0)
    
# Update with version check
updated = Model.objects.filter(
    id=obj.id,
    version=obj.version
).update(
    field=new_value,
    version=F('version') + 1
)

if not updated:
    # Concurrent modification detected
    raise ConcurrencyError()
```

### Pattern: Let Database Enforce Constraints

```python
# Don't check then insert
if not exists:  # ❌ TOCTOU
    create()

# Just try to insert, handle violation
try:  # ✅
    create()
except IntegrityError:
    handle_conflict()
```

## Testing for Concurrency Issues

### Manual Testing Pattern

```python
# Terminal 1
from django.db import transaction
with transaction.atomic():
    obj = Model.objects.select_for_update().get(id=1)
    # Don't commit yet - keep terminal open
    
# Terminal 2 - Try same operation
# Will it block? Will it cause issues?
```

### Unit Test Pattern

```python
from threading import Thread
import pytest

def test_concurrent_updates():
    """Test that concurrent updates don't lose data"""
    
    def increment():
        obj = Model.objects.get(id=1)
        obj.counter = F('counter') + 1
        obj.save()
    
    # Start multiple threads
    threads = [Thread(target=increment) for _ in range(10)]
    for t in threads:
        t.start()
    for t in threads:
        t.join()
    
    # Verify all updates applied
    obj = Model.objects.get(id=1)
    assert obj.counter == 10
```

## Common Patterns Summary

### When to Use Each Approach

| Pattern | Use Case | Pros | Cons |
|---------|----------|------|------|
| F() expressions | Simple increments, calculations | Fast, no locks | Can't use updated value immediately |
| EAFP (try/except) | Creating unique records | Pythonic, no locks | Requires unique constraint |
| select_for_update | Complex updates, consistency | Safe, explicit | Slow under load, serializes |
| Optimistic locking | Rare conflicts expected | Good UX feedback | Extra version field |
| UPDATE RETURNING | Need updated value | Single query | PostgreSQL/SQLite only |

### Decision Tree

```
Need to increment counter?
    → Use F('counter') + 1

Need to create with unique constraint?
    → Use EAFP (try/except IntegrityError)

Complex logic with multiple fields?
    → Consider select_for_update
    → Or restructure to use F() expressions

Under heavy load?
    → Avoid select_for_update if possible
    → Use F() expressions or optimistic locking
```
